<?php

namespace WebpConverterVendor\MattPlugins\DeactivationModal\Exception;

/**
 * .
 */
class DuplicatedFormOptionKeyException extends \Exception
{
}
